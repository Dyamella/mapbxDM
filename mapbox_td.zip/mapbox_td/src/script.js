// AccesToken
//mapboxgl.accessToken = 'pk.eyJ1IjoiZHlhbSIsImEiOiJjbTczNjM3dncwZ2VpMnFxb3pyczBsaDk1In0.dUb9k9mIVwK8XG66C7gzWQ';

// Configuration de la carte
var map = new maplibregl.Map({
container: 'map',
style: 'https://basemaps.cartocdn.com/gl/positron-gl-style/style.json', // Fond de carte
center: [-1.68, 48.11], // lat/long
zoom: 11.5, // zoom
pitch: 20, // Inclinaison
bearing: 0 // Rotation
});

// Gestion du changement de style
document.getElementById('style-selector').addEventListener('change', function () {
    map.setStyle(this.value);
    map.once('style.load', addLayers); // Recharge les couches après changement de style
  });
// Boutons de navigation
var nav = new maplibregl.NavigationControl();
map.addControl(nav, 'bottom-right');

// Ajout Echelle cartographique
map.addControl(new maplibregl.ScaleControl({
maxWidth: 120,
unit: 'metric'}));

// Bouton de géolocalisation
map.addControl(new maplibregl.GeolocateControl
({positionOptions: {enableHighAccuracy: true},
trackUserLocation: true,
showUserHeading: true}));

// Fonction pour ajouter les couches
function addLayers() {
    map.addSource('mapbox-streets-v8', {
        type: 'vector',
        url: 'https://openmaptiles.geo.data.gouv.fr/data/france-vector.json'
    });
//Routes
    map.addLayer({
        "id": "Routes",
        "type": "line",
        "source": "mapbox-streets-v8",
        "layout": {'visibility': 'visible'},
        "source-layer": "transportation",
        "filter": ["all", ["in", "class", "motorway", "trunk", "primary"]],
        "paint": {"line-color": "#DFCFBE", "line-width": 2},
        "maxzoom": 16
    });
  
//Hydro = OSM
   map.addLayer({
        "id": "Hydro",
        "type": "fill",
        "source": "mapbox-streets-v8",
        "layout": {'visibility': 'visible'},
        "source-layer": "water",
        "paint": {"fill-color": "#7FCDCD"}
    });
  
// Batiments : données en tuiles vectorielles depuis IGN
 map.addSource('BDTOPO', {
    type: 'vector',
    url:'https://data.geopf.fr/tms/1.0.0/BDTOPO/metadata.json',
    minzoom: 15,
    maxzoom: 19
  });
  map.addLayer({
    'id': 'batiments',
    'type': 'fill-extrusion',
    'source': 'BDTOPO',
    'source-layer': 'batiment',
    'paint': {'fill-extrusion-color':{'property': 'hauteur',
    'stops':[[10, '#b35806'],
            [25, '#f1a340'],
            [30, '#fee0b6'],
            [45, '#f7f7f7'],
            [60, '#d8daeb'],
            [75, '#998ec3'],
            [100, '#542788']]},
    'fill-extrusion-height':{'type': 'identity','property':'hauteur'},
    'fill-extrusion-opacity': 0.7,
    'fill-extrusion-base': 0}
  }); 
 
// Ajout des contours de Rennes : appel API
dataCadastre = 'https://apicarto.ign.fr/api/cadastre/commune?code_insee=35238';
jQuery.when( jQuery.getJSON(dataCadastre)).done(function(json) {
for (i = 0; i < json.features.length; i++) {
json.features[i].geometry = json.features[i].geometry;
};
map.addLayer(
{'id': 'Contourcommune',
'type':'line',
'source': {'type': 'geojson','data': json},
'paint' : {'line-color': 'black',
'line-width':2.5},
'layout': {'visibility': 'visible'},
});
});

 // Ajout du PLUi = API Carto GPU
dataPLU = 'https://apicarto.ign.fr/api/gpu/zone-urba?partition=DU_243500139';
jQuery.when(jQuery.getJSON(dataPLU)).done(function(json) {
// Filtrer les entités pour ne garder que celles avec typezone = 'U'
var filteredFeatures = json.features.filter(function(feature)
{return feature.properties.typezone === 'N';});
// Créer un objet GeoJSON avec les entités filtrées
var filteredGeoJSON = { type: 'FeatureCollection', features: filteredFeatures};
map.addLayer({
  'id': 'PLU',
  'type': 'fill',
  'source': {'type': 'geojson',
  'data': filteredGeoJSON},
  'paint': {'fill-color': 'green',
  'fill-opacity': 0.5},
  'layout': {'visibility': 'none'},
});
});

//On enrichit avec les Parcs relais = API STAR 
$.getJSON('https://data.rennesmetropole.fr/api/explore/v2.1/catalog/datasets/tco-parcsrelais-star-etat-tr/records?limit=20',
function(data) {var geojsonData4 = {
type: 'FeatureCollection',
features: data.results.map(function(element) {
return {type: 'Feature',
geometry: {type: 'Point',
coordinates: [element.coordonnees.lon, element.coordonnees.lat]},
properties: { name: element.nom,
capacity: element.jrdinfosoliste}};

})
};
                
map.addLayer({ 'id': 'Parcrelais',
'type':'circle',
'source': {'type': 'geojson',
'data': geojsonData4},
'layout': {'visibility': 'visible'},
'paint': {'circle-color': '#9B2335', 'circle-strocke-color' : '#EFC050',
         'circle-radius': {property: 'capacity', type: 'exponential',
          stops: [[1, 5],[500, 40]]},
          'circle-opacity': 0.5}
});
});
 
//station velo STAR : 
$.getJSON('https://data.explore.star.fr/api/explore/v2.1/catalog/datasets/vls-stations-etat-tr/records?limit=60',
function(data) {var geojsonVLS = {
type: 'FeatureCollection',
features: data.results.map(function(element) {
return {type: 'Feature',
geometry: {type: 'Point',
coordinates: [element.coordonnees.lon, element.coordonnees.lat]},
properties: { name: element.nom,
emplacements: element.nombreemplacementsdisponibles,
velos: element.nombrevelosdisponibles}};
})
};
map.addLayer({ 'id': 'velos',
'type':'circle',
'source': {'type': 'geojson',
'data': geojsonVLS},
'layout': {'visibility': 'visible'},
'paint': {'circle-color': 'blue','circle-radius': {property: 'velos', type: 'exponential',
          stops: [[1, 5],[50, 40]]},
          'circle-opacity': 0.5}            
});
});  

//Ajout des bus = API STAR
$.getJSON('https://data.explore.star.fr/api/explore/v2.1/catalog/datasets/tco-bus-vehicules-position-tr/records?limit=100',
function(data) {var geojsonbus = {
type: 'FeatureCollection',
features: data.results.map(function(element) {
return {type: 'Feature',
geometry: {type: 'Point',
coordinates: [element.coordonnees.lon, element.coordonnees.lat]},
properties: { id: element.idbus,
numero: element.numerobus}};
})
};
map.addLayer({ 'id': 'bus',
'type':'circle',
'source': {'type': 'geojson',
'data': geojsonbus},
'layout': {'visibility': 'none'},
'paint': {'circle-color': 'red'}
});
});    

//Ajout des données OSM via l'API = les restaurants de Rennes
const ville = "Rennes";
$.getJSON(`https://overpass-api.de/api/interpreter?data=[out:json];area[name="${ville}"]->.searchArea;(node["amenity"="restaurant"](area.searchArea););out center;`,
function(data) {var geojsonData = {
type: 'FeatureCollection',
features: data.elements.map(function(element) {
return {type: 'Feature',
geometry: { type: 'Point',coordinates: [element.lon, element.lat] },
properties: {}};
})
};
map.addSource('customData', {
type: 'geojson',
data: geojsonData
});
map.addLayer({
'id': 'restaurants',
'type': 'circle',
'source': 'customData',
'paint': {'circle-color': 'purple',
'circle-radius': 3},
'layout': {'visibility': 'visible'}
});
});  

//ARRET DE BUS OSM
$.getJSON(`https://overpass-api.de/api/interpreter?data=[out:json];area[name="${ville}"]->.searchArea;(node["highway"="bus_top"](area.searchArea););out center;`,
function(data) {var geojsonData = {
type: 'FeatureCollection',
features: data.elements.map(function(element) {
return {type: 'Feature',
geometry: { type: 'Point',coordinates: [element.lon, element.lat] },
properties: {}};
})
};
map.addSource('customData', {
type: 'geojson',
data: geojsonData
});
map.addLayer({
'id': 'Arrets',
'type': 'circle',
'source': 'customData',
'paint': {'circle-color': 'red',
'circle-radius': 3},
'layout': {'visibility': 'visible'}
});
});
 
// AJOUT DU CADASTRE ETALAB
map.addSource('Cadastre', {
  type: 'vector',
  url: 'https://openmaptiles.geo.data.gouv.fr/data/cadastre.json' });

map.addLayer({
  'id': 'Cadastre',
  'type': 'line',
  'source': 'Cadastre',
  'source-layer': 'parcelles',
   "filter": [">", "contenance",1000],
  'layout': {'visibility': 'none'},
  'paint': {'line-color': '#515a5a '},
  'minzoom':16, 'maxzoom':19 });

map.setPaintProperty('communeslimites', 'line-width', ["interpolate",["exponential",1],["zoom"],16,0.3,18,1]);

switchlayer = function (lname) {
            if (document.getElementById(lname + "CB").checked) {
                map.setLayoutProperty(lname, 'visibility', 'visible');
            } else {
                map.setLayoutProperty(lname, 'visibility', 'visible');
           }
        }
  
  
}  //FIN DE MAPONE

// Ajout des couches au chargement initial
map.on('load', addLayers);

// Gestion du changement de style
document.getElementById('style-selector').addEventListener('change', function () {
    map.setStyle(this.value);
    map.once('style.load', addLayers); // Recharge les couches après changement de style
});

//////INTERACTIVITE CLICK\\\\\\\\
//Pour le clic arrêt de bus et avoir le nom de l'arrêt de bus et le mobilier en dessous du trait au clic
map.on('click', function (e) {
var features = map.queryRenderedFeatures(e.point, { layers: ['Arrets'] });
  if (!features.length) {
  return;
}
var feature = features[0];
var popup = new maplibregl.Popup({ offset: [0, -15] })
  .setLngLat(feature.geometry.coordinates)
  .setHTML('<h2>' + feature.properties.nom + '</h2><hr><h3>'
  +"Mobilier 🚌 : " + feature.properties.mobilier + '</h3><p>')
  .addTo(map);
});
map.on('mousemove', function (e) {
  var features = map.queryRenderedFeatures(e.point, { layers: ['Arrets'] });
  map.getCanvas().style.cursor = (features.length) ? 'pointer' : '';

});

////////Interactivité CLICK VELO \\\\\\\\\\
map.on('click', function (e) {
var features = map.queryRenderedFeatures(e.point, { layers: ['velos'] });
if (!features.length) {
return;
}
var feature = features[0];
var popup = new maplibregl.Popup({ offset: [0, -15] })
.setLngLat(feature.geometry.coordinates)
.setHTML('<h2>' + feature.properties.name + '</h2><h3>'
+ feature.properties.emplacements + ' socles libres</h3><p>'
+ feature.properties.velos + ' vélos libres ☺️</p>' )

.addTo(map);

});
map.on('mousemove', function (e) {
var features = map.queryRenderedFeatures(e.point, { layers: ['velos'] });
map.getCanvas().style.cursor = (features.length) ? 'pointer' : '';
});


////////Interactivité HOVER\\\\\\\\\\ interactivité "survol" et avoir l'information DES PARCS RELAIS
var popup = new maplibregl.Popup({
  className: "Mypopup",
  closeButton: false,
  closeOnClick: false 
});
map.on('mousemove', function(e) {
var features = map.queryRenderedFeatures(e.point, { layers: ['Parcrelais'] });
// Change the cursor style as a UI indicator.
map.getCanvas().style.cursor = (features.length) ? 'pointer' : '';
if (!features.length)
{
popup.remove();
return;
}
var feature = features[0];
  popup.setLngLat(feature.geometry.coordinates)
  .setHTML('<h2>' + feature.properties.name + '</h2><hr><h3>'
  + feature.properties.capacity +' places disponibles 🚴🏻‍♂️</h3')
  .addTo(map);
});

///configuration des onglets géographiques Gare
document.getElementById('Gare').addEventListener('click', function ()
{ map.flyTo({zoom: 16,
center: [-1.672, 48.1043],
pitch: 30 });
});

///configuration des onglets géographiques Rennes1
document.getElementById('Rennes1').addEventListener('click', function ()
{ map.flyTo({zoom: 16,
center: [-1.649, 48.124],
pitch: 10 });
});

///configuration des onglets géographiques Rennes2
document.getElementById('Rennes2').addEventListener('click', function ()
{ map.flyTo({zoom: 16,
center: [-1.704, 48.119],
pitch: 30 });
});

//configuration des onglets géographiques restaurant
document.getElementById('B-Grill').addEventListener('click', function ()
{ map.flyTo({zoom: 16,
center: [-1.590, 48.112],
pitch: 20 });
});
